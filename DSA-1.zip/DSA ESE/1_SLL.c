#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *next;
}*first = NULL;
int count(struct Node *p){
    int l = 0;
    while(p){
        l++;
        p = p->next;
    }
    return l;
}
void insert(struct Node *p, int index, int x){
    if(index < 0 || index > count(p)){
        return;
    }
    struct Node *t;
    t = (struct Node *)malloc(sizeof(struct Node));
    t->data = x;
    int i;
    if(index == 0){
        t->next = first;
        first = t;
    }else{
        for(i=0;i<index-1;i++){
            p = p->next;
        }
        t->next = p->next;
        p->next = t;
    }
}
void display(struct Node *p){
    int n = count(p);
    for(int i=0;i<n;i++){
        printf("%d ", p->data);
        p = p->next;
    }
}
int main(){
    insert(first,0, 10);
    insert(first,1, 20);
    insert(first,2, 30);
    insert(first,3, 40);
    insert(first,4, 50);
    display(first);


    return 0;
}