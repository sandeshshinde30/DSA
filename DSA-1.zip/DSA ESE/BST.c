#include<stdio.h>
#include<stdio.h>
#include "cqueue.h"
struct Node *root = NULL;
void Tcreate(){
    int x;
    struct Queue q;
    create(&q,20);
    printf("Enter root value : ");
    scanf("%d", &x);
    root = (struct Node*)malloc(sizeof(struct Node));
    root->data = x;
    root->lchild = root->rchild = NULL;
}
void insert(struct Node *p, int key){
    struct Node *last = p;
    if(last){
    if(last->data < key){
        insert(last->rchild, key);
    }else if(last->data > key){
        insert(last->lchild, key);
    }
    }
    else{
    struct Node *t;
    t = (struct Node *)malloc(sizeof(struct Node));
    t->data = key;
    t->lchild = t->rchild = NULL;
    last = t;
    }
}
void preorder(struct Node *p){
    if(p){
    printf("%d ", p->data);
    preorder(p->lchild);
    preorder(p->rchild);
    }
} 
int main(){
    Tcreate();
    insert(root, 12);
    insert(root, 8);
    insert(root, 9);
    insert(root, 15);
    preorder(root);

    return 0;
}