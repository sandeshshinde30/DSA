#include<stdio.h>
#include<stdlib.h>
struct Node{
    struct Node *prev;
    int data;
    struct Node *next;
}*first = NULL;
void create(){
    first = (struct Node*)malloc(sizeof(struct Node));
    int n;
    printf("Enter 1st Node data : ");
    scanf("%d",&n);
    first->data = n;
    first->prev = first->next = NULL;
}
void insert(struct Node *p, int x){
    struct Node *t;
    t = (struct Node*)malloc(sizeof(struct Node));
    t->data = x;
    t->next = NULL;
    while(p->next){
        p = p->next;
    }
    p->next = t;
    t->prev = p;
}
void display(struct Node *p){
    while(p){
        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");
}
int main(){
    create();
    // insert(first, 15);
    insert(first, 30);
    insert(first, 45);
    insert(first, 60);
    insert(first, 75);
    display(first);
    return 0;
}