#include<stdio.h>
#include<stdlib.h>
struct Node{
    // struct Node *prev;
    int data;
    struct Node *next;
}*first=NULL;
void tcreate(){
    first = (struct Node *)malloc(sizeof(struct Node));
    int x;
    printf("Enter first Node : ");
    scanf("%d", &x);
    first->data = x;
    first->next = NULL;
}
int count(struct Node *p){
    int l = 0;
    while(p){
        l++;
        p = p->next;
    }
    return l;
}
void insert(struct Node *p,int index, int x){
    if(index < 0 || index > count(p)){
        return;
    }
    struct Node *t;
    t = (struct Node *)malloc(sizeof(struct Node));
    t->data = x;

    if(index == 0){
        t->next = first;
        first = t;
    }else{
        int i;
        for(i=0;i<index-1;i++){
            p = p->next;
        }
        t->next = p->next;
        p->next = t;
    }

}
void display(struct Node *p){
    while(p){
        printf("%d ",p->data);
        p = p->next;
    }
}
int main(){
    tcreate();
    insert(first, 0, 10);
    insert(first, 1, 15);
    insert(first, 2, 20);
    display(first);


    return 0;
}