#include<stdio.h>
#include<stdlib.h>
struct Node{
    int coeff;
    int power;
    struct Node *next;
}*poly1 = NULL, *poly2 = NULL;
struct Node * create(struct Node *p){
    struct Node *t,*last=NULL;
    int n;
    printf("Enter number of terms in given polynomial : ");
    scanf("%d",&n);
    printf("Enter coeff & powers of each number : ");
    for(int i=0;i<n;i++)
    {
        t=(struct Node *)malloc(sizeof(struct Node));
        scanf("%d%d",&t->coeff,&t->power);
        t->next=NULL;
        if(p==NULL)
        {
            p=last=t;
        }
        else
        {
            last->next=t;
            last=t;
        }
    }
    return p;   
}
struct Node * addPolynomials(struct Node *p1, struct Node *p2){
    struct Node *result = NULL;
    struct Node *temp, *last = NULL;

    while (p1 != NULL && p2 != NULL)
    {
        temp = (struct Node *)malloc(sizeof(struct Node));
        temp->next = NULL;

        if (p1->power > p2->power)
        {
            temp->coeff = p1->coeff;
            temp->power = p1->power;
            p1 = p1->next;
        }
        else if (p1->power < p2->power)
        {
            temp->coeff = p2->coeff;
            temp->power = p2->power;
            p2 = p2->next;
        }
        else
        {
            temp->coeff = p1->coeff + p2->coeff;
            temp->power = p1->power;
            p1 = p1->next;
            p2 = p2->next;
        }

        if (result == NULL)
        {
            result = last = temp;
        }
        else
        {
            last->next = temp;
            last = temp;
        }
    }

    while (p1 != NULL)
    {
        temp = (struct Node *)malloc(sizeof(struct Node));
        temp->next = NULL;
        temp->coeff = p1->coeff;
        temp->power = p1->power;
        p1 = p1->next;

        if (result == NULL)
        {
            result = last = temp;
        }
        else
        {
            last->next = temp;
            last = temp;
        }
    }

    while (p2 != NULL)
    {
        temp = (struct Node *)malloc(sizeof(struct Node));
        temp->next = NULL;
        temp->coeff = p2->coeff;
        temp->power = p2->power;
        p2 = p2->next;

        if (result == NULL)
        {
            result = last = temp;
        }
        else
        {
            last->next = temp;
            last = temp;
        }
    }

    return result;
}
void display(struct Node *p){
    while(p){
        printf("%dx^%d", p->coeff,p->power);
        if (p->next) {
            printf(" + ");
        }
        p = p->next;
    }
}
int main(){
    struct Node *a=create(poly1);
    struct Node *b=create(poly2);
    struct Node *result=addPolynomials(a,b);
    display(result);

    return 0;
}