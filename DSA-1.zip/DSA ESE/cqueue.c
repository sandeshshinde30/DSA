#include<stdio.h>
#include<stdlib.h>
struct Cqueue{
    int *arr;
    int size;
    int rear;
    int front;
};
void create(struct Cqueue *q, int size){
    // q = (struct Cqueue*)malloc(sizeof(struct Cqueue));
    q->size = size;
    q->arr = (int*)malloc(sizeof(int)*q->size);
    q->rear = q->front = -1;
}
void enqueue(struct Cqueue *q, int data){
    if((q->rear+1)%q->size == q->front){
        printf("Full.\n");
        return;
    }else{
        q->rear = (q->rear+1)%q->size;
        q->arr[q->rear] = data;
        if(q->front == -1){
            q->front = 0;
        }
    }
}
void dequeue(struct Cqueue *q){
    if(q->front == q->rear){
      q->front = q->rear = -1;  
    }else{
        q->front = (q->front+1)%q->size;
    }
}
void display(struct Cqueue q){
    int i=q.front;
    printf("\n");
    do{
        printf("%d ",q.arr[i]);
        i = (i+1)%q.size;
    }while(i!= (q.rear+1)% q.size);
    printf("\n");
}
int main(){
    struct Cqueue q;
    create(&q, 5);
    enqueue(&q, 4);
    enqueue(&q, 8);
    enqueue(&q, 12);
    enqueue(&q, 16);
    enqueue(&q, 20);
    display(q);
    enqueue(&q, 24);

    dequeue(&q);
    dequeue(&q);
    display(q);
    enqueue(&q, 9);
    enqueue(&q, 81);
    display(q);
    return 0;
}