#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *next;
}*first = NULL;
static int count = 1;
struct Node * create(){
    struct Node *t;
    t = (struct Node*)malloc(sizeof(struct Node));
    int x; 
    printf("Put data of list %d :  ", count);
    scanf("%d", &x);
    t->data = x;
    t->next = NULL;
    count++;
    return t;
}
void insert(struct Node *p, int x){
    struct Node *t;
    t = (struct Node*)malloc(sizeof(struct Node));
    t->data = x;
    t->next = NULL;
    while(p){
        p = p->next;
    }
    p->next = t;
}
void display(struct Node *p){
    while(p){
        printf("%d ", p->data);
        p = p->next;
    }
}
int main(){
    struct Node *last;
    printf("Enter total list : ");
    int n;
    scanf("%d", &n);
    last = first;
    for(int i=0;i<n;i++){
        last->next = create();
        last = last->next;
    }
    display(first);
    return 0;
}