#include<stdio.h>
#include<stdlib.h>
struct Queue{
    int size;
    int front;
    int rear;
    int *Q;
}*front=NULL, *rear=NULL;
void create(struct Queue *q, int size){
    q->size = size;
    q->front = q->rear = -1;
    q->Q=(int *)malloc(q->size*sizeof(int));
};
void enqueue(struct Queue *q){
    if(q->rear == q-> size-1){
        printf("\nQueue is Full");
        return;
    }else{
        int x;
        printf("Enter item : ");
        scanf(" %d", &x);
        q->rear++;
        q->Q[q->rear] = x;
    }
};
int dequeue(struct Queue *q){
    int x = -1;
    if(q->front == q->rear){
        printf("\nQueue is Empty.");
    }else{
        q->front++;
        x = q->Q[q->front];
    }
    return x;
};
void Display(struct Queue q){
    for(int i = q.front+1;i<=q.rear;i++){
        printf("%d ", q.Q[i]);
    }
    printf("\n");
};
int main(){
    struct Queue q;
    create(&q,10);
    char choice = 'y';
    while(choice == 'y'){
    printf("1: Insert\t2: Delete\t3: Display");
    int n;
    printf("\nEnter your choice : ");
    scanf(" %d", &n);
    switch(n){
        case 1 : enqueue(&q);
        break;
        case 2 : dequeue(&q);
        break;
        case 3 : Display(q);
        break;
        default : printf("\nInvalid choie");
    }
    printf("Operate again? (y/n) : ");
    scanf(" %c", &choice);
    }
    return 0;
}