#include<stdio.h>
#include<stdlib.h>
void ins_sort(int *arr, int n){
    int current = 1, hold, walker;
    while(current<=n){
        hold = arr[current];
        walker = current -1;
        while(walker>=0 && hold < arr[walker]){
            arr[walker+1] = arr[walker];
            walker--;
        }
        arr[walker+1] = hold;
        current++;
    }
}
void shell_sort(int *arr, int n){
    int gap = n/2;
    while(gap != 0){
    int current = gap, hold, walker;
    while(current<=n){
        hold = arr[current];
        walker = current - gap;
        while(walker>=0 && hold < arr[walker]){
            arr[walker+gap] = arr[walker];
            walker-= gap;
        }
        arr[walker+gap] = hold;
        current++;
    }
    gap = gap/2;
    }
}
void quick_sort(int *list, int left, int right){
    if(left<right){
    int pivot = left;
    int i = left+1;
    int j = right;
    if(i<=j){

    while(list[i]<list[pivot] && i<=right){
        i++;
    }

    while(list[j]>list[pivot] && j>=i){
        j--;
    }

    if(i<j){
        int x = list[i];
        list[i] = list[j];
        list[j] = x;
        i++;
        j--;
    }

    }

    int x = list[j];
    list[j] = list[pivot];
    list[pivot] = x;

    quick_sort(list, left, j-1);
    quick_sort(list,j+1,right);
    }
}
void merge(int *list, int left, int mid, int right);
void mergesort(int *list, int left, int right){
    if(left<right){
        int mid = (left+right)/2;
        mergesort(list, left, mid);
        mergesort(list,mid+1,right);
        merge(list, left, mid, right);
    }
}
void merge(int *list, int left, int mid, int right){
    int B[right], r = 0;
    int i = left, j = mid+1;
    while(i<=mid && j<=right){
        if(list[i] <= list[j]){
            B[r] = list[i];
            r++;
            i++;
        }else if(list[i] > list[j]){
            B[r] = list[j];
            r++;
            j++;
        }
    }
    while(i<=mid){
            B[r] = list[i];
            r++;
            i++;
    }
    while(j<=right){
            B[r] = list[j];
            r++;
            j++;
        }
    for(int k = left,i = 0;k<=right;k++,i++){
        list[k] = B[i];
    }
}
void bubblesort(int *list, int n){
    int i,j;
    for(i=0;i<n-1;i++){
        for(j=0;j<n-1-i;j++){
            if(list[j]>list[j+1]){
                int x = list[j];
                list[j] = list[j+1];
                list[j+1] = x;
            }
        }
    }
}
void display(int *arr){
    int i;
    for(i=0;i<5;i++){
        printf("%d ", arr[i]);
    }
    printf("\n");
}
int main(){
    int a[5] = {23,45,6,12,8};
    printf("List Before : ");
    display(a);

    printf("List After : ");
    // ins_sort(a,4);
    // shell_sort(a,4);
    //quick_sort(a, 0, 4);
    //mergesort(a,0,4);
    bubblesort(a,5);
    display(a);
    
    return 0;
}