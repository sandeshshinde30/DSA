#include <stdio.h>
#include <stdlib.h>

struct Node {
    struct Node* lchild;
    int data;
    struct Node* rchild;
};

struct BST {
    struct Node* root;
};

void BST_Init(struct BST* tree) {
    tree->root = NULL;
}

struct Node* Insert(struct Node* root, int key) {
    if (root == NULL) {
        struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
        newNode->data = key;
        newNode->lchild = NULL;
        newNode->rchild = NULL;
        return newNode;
    }

    if (key < root->data) {
        root->lchild = Insert(root->lchild, key);
    } else if (key > root->data) {
        root->rchild = Insert(root->rchild, key);
    }

    return root;
}

void Inorder(struct Node* p) {
    if (p) {
        Inorder(p->lchild);
        printf("%d ", p->data);
        Inorder(p->rchild);
    }
}

struct Node* Search(struct Node* root, int key) {
    struct Node* t = root;
    while (t != NULL) {
        if (key == t->data) {
            return t;
        } else if (key < t->data) {
            t = t->lchild;
        } else {
            t = t->rchild;
        }
    }
    return NULL;
}

int main() {
    struct BST bst;
    BST_Init(&bst);

    // Insert
    bst.root = Insert(bst.root, 10);
    bst.root = Insert(bst.root, 5);
    bst.root = Insert(bst.root, 20);
    bst.root = Insert(bst.root, 8);
    bst.root = Insert(bst.root, 30);

    // Inorder traversal
    Inorder(bst.root);
    printf("\n");

    // Search
    struct Node* temp = Search(bst.root, 20);
    if (temp != NULL) {
        printf("Element %d found.\n", temp->data);
    } else {
        printf("Element not found\n");
    }

    return 0;
}
