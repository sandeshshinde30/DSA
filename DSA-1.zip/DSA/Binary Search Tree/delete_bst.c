#include<stdio.h>
#include<stdlib.h>
struct node 
{
    struct node *lchild;
    int data;
    struct node *rchild;
};
struct queue  
{
    int size;
    int front;
    int rear;
    struct node **Q;
};
void create(struct queue *q,int z)
{
    q->size=z;
    q->front = q->rear = 0;
    q->Q=(struct node**)malloc(q->size*sizeof(struct node *));
}
void enqueue(struct queue *q,struct node *x)
{
    if((q->rear+1)%q->size==q->front)
    {
        printf("Queue full\n");
    }
    else
    {
        q->rear=(q->rear+1)%q->size;
        q->Q[q->rear]=x;
    }
}
struct node * dequeue(struct queue *q)
{
    struct node *x=NULL;
    if(q->front==q->rear)
    {
        printf("queue is empty\n");
    }
    else
    {
        q->front=(q->front+1)%q->size;
        x=q->Q[q->front];
    }
    return x;
}
int isEmpty(struct queue q)
{
    if(q.front==q.rear)
    {
        return 1;
    }
    return 0;
}
struct node*root=NULL;
void inorder_traversal(struct node *p)
{
    if(p!=NULL)
    {
    inorder_traversal(p->lchild);
    printf("%d ",p->data);
    inorder_traversal(p->rchild);
    }
}
void Tree_create()
{
    struct node *t,*p;
    struct queue q;
    create(&q,50);
    int x;
    printf("Enter root value :");
    scanf("%d",&x);
    root=(struct node*)malloc(sizeof(struct node));
    root->data=x;
    root->lchild=root->rchild=NULL;
    enqueue(&q,root);
    while(!isEmpty(q))
    {
        p=dequeue(&q);
        printf("Enter left child for %d : ",p->data);
        scanf("%d",&x);
        if(x!=-1)
        {
            t=(struct node *)malloc(sizeof(struct node));
            t->data=x;
            t->lchild=t->rchild=NULL;
            p->lchild=t;
            enqueue(&q,t);
        }
        printf("Enter right child for %d : ",p->data);
        scanf("%d",&x);
        if(x!=-1)
        {
            t=(struct node *)malloc(sizeof(struct node));
            t->data=x;
            t->rchild=t->lchild=NULL;
            p->rchild=t;
            enqueue(&q,t);
        }
    }
}
struct node * inpred(struct node *p)
{
    while(p!=NULL && p->rchild!=NULL)
    {
        p=p->rchild;
    }
    return p;
}
struct node * insucc(struct node *p)
{
    while(p!=NULL && p->lchild!=NULL)
    {
        p=p->lchild;
    }
    return p;
}
int no_of_nodes(struct node *p)
{
    int x,y;
    if(p!=NULL)
    {
        x=no_of_nodes(p->lchild);
        y=no_of_nodes(p->rchild);
        return x+y+1;
    }
}
struct node * deletion(struct node *p,int key)
{
    struct node *q;
    if(p==NULL)
    {
        return NULL;
    }
    else if(p->lchild==NULL && p->rchild==NULL)
    {
        if(p==root)
        {
            root=NULL;
        }
        free(p);
        return NULL;
    }
    else if(key<p->data)
    {
        p->lchild=deletion(p->lchild,key);
    }
    else if(key>p->data)
    {
        p->rchild=deletion(p->rchild,key);
    }
    else
    {
        if(no_of_nodes(p->lchild)>no_of_nodes(p->rchild))
        {
            q=inpred(p);
            p->data=q->data;
            p->lchild=deletion(p->lchild,q->data);
        }
        else if(no_of_nodes(p->lchild)<no_of_nodes(p->rchild))
        {
            q=insucc(p);
            p->data=q->data;
            p->rchild=deletion(p->rchild,q->data);
        }
        else if(p->lchild==NULL && p->rchild!=NULL)
        {
            q=p;
            p=p->rchild;
            free(q);
            return p;
        }
        else if(p->rchild==NULL && p->lchild!=NULL)
        {
            q=p;
            p=p->lchild;
            free(q);
            return p;
        }
    }
}

int main()
{
    Tree_create();
    struct node * temp;
    temp=deletion(root,5);
    printf("%d",temp->data);
    inorder_traversal(root);
}