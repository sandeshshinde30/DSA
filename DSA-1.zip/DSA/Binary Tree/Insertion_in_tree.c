#include<stdio.h>
#include<stdlib.h>
struct node 
{
    struct node *lchild;
    int data;
    struct node *rchild;
};
struct queue  
{
    int size;
    int front;
    int rear;
    struct node **Q;
};
void create(struct queue *q,int z)
{
    q->size=z;
    q->front = q->rear = 0;
    q->Q=(struct node**)malloc(q->size*sizeof(struct node *));
}
void enqueue(struct queue *q,struct node *x)
{
    if((q->rear+1)%q->size==q->front)
    {
        printf("Queue full\n");
    }
    else
    {
        q->rear=(q->rear+1)%q->size;
        q->Q[q->rear]=x;
    }
}
struct node * dequeue(struct queue *q)
{
    struct node *x=NULL;
    if(q->front==q->rear)
    {
        printf("queue is empty\n");
    }
    else
    {
        q->front=(q->front+1)%q->size;
        x=q->Q[q->front];
    }
    return x;
}
int isEmpty(struct queue q)
{
    if(q.front==q.rear)
    {
        return 1;
    }
    return 0;
}
struct node*root=NULL;
void Tree_create()
{
    struct node *t,*p;
    struct queue q;
    create(&q,50);
    int x;
    printf("Enter root value :");
    scanf("%d",&x);
    root=(struct node*)malloc(sizeof(struct node));
    root->data=x;
    root->lchild=root->rchild=NULL;
    enqueue(&q,root);
    while(!isEmpty(q))
    {
        p=dequeue(&q);
        printf("Enter left child for %d : ",p->data);
        scanf("%d",&x);
        if(x!=-1)
        {
            t=(struct node *)malloc(sizeof(struct node));
            t->data=x;
            t->lchild=t->rchild=NULL;
            p->lchild=t;
            enqueue(&q,t);
        }
        printf("Enter right child for %d : ",p->data);
        scanf("%d",&x);
        if(x!=-1)
        {
            t=(struct node *)malloc(sizeof(struct node));
            t->data=x;
            t->rchild=t->lchild=NULL;
            p->rchild=t;
            enqueue(&q,t);
        }
    }
}
void inorder_traversal(struct node *p)
{
    if(p!=NULL)
    {
    inorder_traversal(p->lchild);
    printf("%d ",p->data);
    inorder_traversal(p->rchild);
    }
}
void insertion(struct node *p,int key)
{
    struct node *r=NULL;
    struct node *t;
    if(p==NULL)
    {
        t=(struct node *)malloc(sizeof(struct node));
        t->data=key;
        t->lchild=t->rchild=NULL;
        root=t; //check
    }
    while(p!=NULL)
    {
        r=p;
        if(p->data==key)
        {
            return ;
        }
        else if(key<p->data)
        {
            p=p->lchild;
        }
        else if(key>p->data)
        {
            p=p->rchild;
        }
    }
    t=(struct node *)malloc(sizeof(struct node));
    t->data=key;
    t->lchild=t->rchild=NULL;
    if(key<r->data)
    {
        r->lchild=t;
    }
    else if(key>r->data)
    {
        r->rchild=t;
    }
}
int main()
{
    Tree_create();
    insertion(root,6);
    insertion(root,7);
    insertion(root,8);
    insertion(root,2);
    insertion(root,1);
    insertion(root,16);
    inorder_traversal(root);
}