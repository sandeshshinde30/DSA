#include<stdio.h>
#include<stdlib.h>
#include "stack.h"
#include "cqueue.h"
struct Node *root = NULL;
void Tcreate(){
    struct Node *p, *t;
    int x;
    struct Queue q;
    create(&q, 20);
    printf("Enter root value : ");
    scanf("%d", &x);
    root = (struct Node *)malloc(sizeof(struct Node));
    root->data = x;
    root->lchild = root->rchild = NULL;
    enqueue(&q, root);
    while(!isEmpty(q)){
        p = dequeue(&q);

        printf("Enter left child of %d : ", p->data);
        scanf("%d", &x);
        if(x != -1){
            t = (struct Node *)malloc(sizeof(struct Node));
            t->data = x;
            t->lchild = t->rchild = NULL;
            p->lchild = t;
            enqueue(&q, t);
        }

        printf("Enter right child %d : ", p->data);
        scanf("%d", &x);
        if(x != -1){
            t = (struct Node *)malloc(sizeof(struct Node));
            t->data = x;
            t->lchild = t->rchild = NULL;
            p->rchild = t;
            enqueue(&q, t);
        }
    }
}
void IPreorder(struct Node *p){
    struct Stack stk;
    Screate(&stk, 100);
    while(p || !isEmptyStack(stk)){
        if(p){
            printf("%d ", p->data);
            push(&stk, p);
            p = p->lchild;
        }else{
            p = pop(&stk);
            p = p->rchild;
        }
    }
}

void IInorder(struct Node *p){
    struct Stack stk;
    Screate(&stk, 100);
    while(p || !isEmptyStack(stk)){
        if(p){
            push(&stk, p);
            p = p->lchild;
        }else{
            p = pop(&stk);
            printf("%d ", p->data);
            p = p->rchild;
        }
    }
}

void IPostorder(struct Node *p){
    struct Stack stk;
    long int temp;
    Screate(&stk, 100);
    while(p || !isEmptyStack(stk)){
        if(p){
            push(&stk, p);
            p = p->lchild;
        }else{
            temp = pop(&stk);
            if(temp > 0){
                push(&stk, -temp);
                p = ((struct Node *)temp)->rchild;
            }else{
                printf("%d ", ((struct Node *)temp)->data);
                p = NULL;
            }
        }
    }
}

int main(){
    Tcreate();
    printf("PreOrder : ");
    IPreorder(root);
    printf("\nInOrder : ");
    IInorder(root);
    printf("\nPostOrder : ");
    IPostorder(root);
    return 0;
}