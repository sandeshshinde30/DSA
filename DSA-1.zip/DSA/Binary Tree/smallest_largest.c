#include<stdio.h>
#include<stdlib.h>
struct node 
{
    struct node *lchild;
    int data;
    struct node *rchild;
};
struct queue  
{
    int size;
    int front;
    int rear;
    struct node **Q;
};
void create(struct queue *q,int z)
{
    q->size=z;
    q->front = q->rear = 0;
    q->Q=(struct node**)malloc(q->size*sizeof(struct node *));
}
void enqueue(struct queue *q,struct node *x)
{
    if((q->rear+1)%q->size==q->front)
    {
        printf("Queue full\n");
    }
    else
    {
        q->rear=(q->rear+1)%q->size;
        q->Q[q->rear]=x;
    }
}
struct node * dequeue(struct queue *q)
{
    struct node *x=NULL;
    if(q->front==q->rear)
    {
        printf("queue is empty\n");
    }
    else
    {
        q->front=(q->front+1)%q->size;
        x=q->Q[q->front];
    }
    return x;
}
int isEmpty(struct queue q)
{
    if(q.front==q.rear)
    {
        return 1;
    }
    return 0;
}
struct node*root=NULL;
void tree_create()
{
    struct queue q;
    int x;
    struct node *p,*t;
    create(&q,50);
    printf("Enter root : ");
    scanf("%d",&x);
    root=(struct node*)malloc(sizeof(struct node));
    root->data=x;
    root->lchild=root->rchild=NULL;
    enqueue(&q,root);
    while(!isEmpty(q))
    {
        p=dequeue(&q);
        printf("Enter left child for %d : ",p->data);
        scanf("%d",&x);
        if(x!=-1)
        {
            t=(struct node *)malloc(sizeof(struct node ));
            t->data=x;
            t->lchild=t->rchild=NULL;
            p->lchild=t;
            enqueue(&q,t);
        }
        printf("Enter right child for %d : ",p->data);
        scanf("%d",&x);
        if(x!=-1)
        {
            t=(struct node *)malloc(sizeof(struct node ));
            t->data=x;
            t->lchild=t->rchild=NULL;
            p->rchild=t;
            enqueue(&q,t);
        }
    }
}
struct node* smallest_in_tree(struct node *p)
{
    struct node *x;
    while(p!=NULL)
    {
        x=p;
        p=p->lchild;
    }
    return x;
}
struct node* largest_in_tree(struct node *p)
{
    struct node *x;
    while(p!=NULL)
    {
        x=p;
        p=p->rchild;
    }
    return x;
}
int main()
{
    tree_create();
    printf("\n");
    printf("%d",smallest_in_tree(root)->data);
    printf("\n");
    printf("%d",largest_in_tree(root)->data);
}