#include<stdio.h>
#include<stdlib.h>
#include "cqueue.h"
struct node 
{
    int data;
    struct node *next;
}*front=NULL,*rear=NULL;
void Enqueue(int x)
{
    struct node *t;
    t=(struct node *)malloc(sizeof(struct node));
    t->data=x;
    if(t==NULL)
    {
        printf("Heap full\n");
    }
    else
    {
        t->data=x;
        t->next=NULL;
        if(front==NULL)
        {
            front=rear=t;
        }
        else
        {
            rear->next=t;
            rear=t;
        }
    }
}
int Dequeue()
{
    int x=-1;
    struct node *p=NULL;
    if(front==NULL)
    {
        printf("Q empty \n");
    }
    else
    {
        p=front;
        front=front->next;
        x=p->data;
        free(p);
    }
    return x;
}
int isEmpty1()
{
    return front==NULL;
}

void BFS(int G[][7], int start, int n){
    int i=start,j;
    struct Queue q;
    int visited[7]={0};

    printf("%d ",i);
    visited[i]=1;
    Enqueue(i);

    while(!isEmpty1()){
        i=Dequeue();
        for(j=1;j<n;j++){
            if(G[i][j] == 1 && visited[j] == 0){
                printf("%d ",j);
                visited[j] =1;
                Enqueue(j);
            }
        }
    }

}
void DFS(int G[][7], int start, int n){
    static int visited[7] = {0};
    int j;
    if(visited[start]==0){
        printf("%d ",start);
        visited[start]=1;
        for(j=1;j<n;j++){
            if(G[start][j]==1 && visited[j] == 0){
                DFS(G,j,n);
            }
        }
    }
}
int main()
{
    int G[7][7]={{0,0,0,0,0,0,0},
               {0,0,1,1,0,0,0},
               {0,1,0,0,1,0,0},
               {0,1,0,0,1,0,0},
               {0,0,1,1,0,1,1},
               {0,0,0,0,1,0,0},
               {0,0,0,0,1,0,0}};
    BFS(G,2,7);
    printf("\n");
    DFS(G,2,7);
}