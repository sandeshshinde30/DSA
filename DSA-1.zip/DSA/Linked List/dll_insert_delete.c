#include<stdio.h>
#include<stdlib.h>
struct Node{
    struct Node *prev;
    int data;
    struct Node *next;
}*first;
void create(int A[], int n){
    struct Node *t, *last;
    int i;
    first = (struct Node *)malloc(sizeof(struct Node));
    first->data = A[0];
    first->prev = first->next = NULL;
    last = first;
    for(i=1;i<n;i++){
        t = (struct Node *)malloc(sizeof(struct Node));
        t->data = A[i];
        t->next = last->next;
        t->prev = last;
        last->next = t;
        last = t;
    }
}
void Display(struct Node *p){
    while(p){
        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");
}
int count(struct Node *p){
    int l = 0;
    while(p){
        l++;
        p = p->next;
    }
    return l;
}
void insert(struct Node *p){
    struct Node *t;
    int x, index, i;
    printf("Enter data : ");
    scanf("%d", &x);
    printf("Enter position : ");
    scanf("%d", &index);
    if(index < 0 || index > count(p)){
        printf("Invalid index.");
        return;
    }
    if(index == 0){
    t = (struct Node *)malloc(sizeof(struct Node));
    t->data = x;
    t->prev = NULL;
    t->next = first;
    first->prev = t;
    first = t;
    }else{
        for(i=0;i<index-1;i++){
            p=p->next;
        }
        t = (struct Node *)malloc(sizeof(struct Node));
        t->data = x;
        t->prev = p;
        t->next = p->next;
        if(p->next){
            p->next->prev = t;
        }
        p->next = t;
    }
}
void delete(struct Node *p){
    int index,i;
    struct Node *q;
    printf("Enter index : ");
    scanf("%d", &index);
    if(index <1 || index > count(p)){
        return;
    }
    if(index == 1){
        first = first->next;
        if(first){
            first->prev = NULL;
            printf("%d is Deleted.", p->data);
            free(p);
        }
    }else{
        for(i=0;i<index-1;i++){
            p=p->next;
        }
        p->prev->next = p->next;
        if(p->next){
            p->next->prev = p->prev;
        }
            printf("%d is Deleted.\n", p->data);
            free(p);
    }
}
int main(){

    int A[] = {12,24};
    create(A,2);
    insert(first);
    insert(first);
    Display(first);
    delete(first);
    Display(first);
    return 0;
}