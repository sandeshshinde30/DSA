#include<stdio.h>
#include<stdlib.h>
struct Node{
    struct Node *prev;
    int data;
    struct Node *next;
}*first;
void create(int A[], int n){
    struct Node *t, *last;
    int i;
    first = (struct Node *)malloc(sizeof(struct Node));
    first->data = A[0];
    first->prev = first->next = NULL;
    last = first;
    for(i=1;i<n;i++){
        t = (struct Node *)malloc(sizeof(struct Node));
        t->data = A[i];
        t->next = last->next;
        t->prev = last;
        last->next = t;
        last = t;
    }
}
void Display(struct Node *p){
    while(p){
        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");
}
int count(struct Node *p){
    int l = 0;
    while(p){
        l++;
        p = p->next;
    }
    return l;
}
void Reverse(struct Node *p){
    struct Node *temp;
    while(p!= NULL){
        temp = p->next;
        p->next = p->prev;
        p->prev = temp;
        p= p->prev;
        if(p!= NULL && p->next == NULL){
            first = p;
        }
    }
}
int main(){

    int A[] = {12,24,36,48,60};
    create(A,5);
    printf("Before : ");
    Display(first);
    
    Reverse(first);
    printf("After : ");
    Display(first);

    return 0;
}