#include<stdio.h>
#include<stdlib.h>
struct Node{
    struct Node *prev;
    int data;
    struct Node *next;
}*first;
void create(int A[], int n){
    struct Node *t, *last;
    int i;
    first = (struct Node *)malloc(sizeof(struct Node));
    first->data = A[0];
    first->prev = first->next = NULL;
    last = first;
    for(i=1;i<n;i++){
        t = (struct Node *)malloc(sizeof(struct Node));
        t->data = A[i];
        t->next = last->next;
        t->prev = last;
        last->next = t;
        last = t;
    }
}
void Display(struct Node *p){
    while(p){
        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");
}
int count(struct Node *p){
    int l = 0;
    while(p){
        l++;
        p = p->next;
    }
    return l;
}
void Search(struct Node *p){
    int key;
    printf("Enter element : ");
    scanf("%d", &key);
    while(p){
        if(p->data == key){
            printf("%d Element Found.", key);
            return;
        }else{
            p = p->next;
        }
    }
        printf("Element not found.");
        return;
}
int main(){

    int A[] = {12,24,36,48,60};
    create(A,5);
    Display(first);
    Search(first);

    return 0;
}