#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node *next;
}*first;
int count(struct Node *p){
    int l = 0;
    while(p){
        l++;
        p = p->next;
    }
    return l;
}
void Insert(struct Node *p){
    int x, index;
    printf("Enter Index : ");
    scanf("%d", &index);
    printf("Enter item : ");
    scanf("%d", &x);
    struct Node *t;
    if(index < 0 || index > count(p) + 1 ){
        return;
    }
    t = (struct Node *)malloc(sizeof(struct Node));
    t->data = x;
    int i;
    if(index == 0){
        t->next = first;
        first = t;
    }else{ 
        for(i=0;i<index-1;i++){
            p = p->next;
        }
        t->next = p->next;
        p->next = t;
    }

}
void Delete(struct Node *p){
    struct Node *q;
    int x = -1,i, index;
    printf("Enter index to delete : ");
    scanf("%d ", &index);
    if(index < 1 || index > count(p)){
        printf("Invalid index.");
    }else{
        if(index == 1){
            q = first;
            x = first->data;
            first = first->next;
            free(p);
            printf("%d Deleted.", x);
        }else{
            for(i=0;i<index-1;i++){
                q = p;
                p = p->next;
            }
            q->next = p->next;
            x = p->data;
            free(p);
            printf("%d Deleted.", x);
        }
    }
}
void RDisplay(struct Node *p){
    int n = count(p);
    for(int i=0;i< n;i++){
        printf("%d ", p->data);
        p = p->next;
    }
}
int main(){
    int a = 1;
    while(a == 1){
    printf("Total Nodes : %d\n", count(first));
    printf("1. Insertion \n2. Deletetion\n3. Display\n");
    printf("Your Choice : ");
    int n;
    scanf(" %d", &n);
    switch(n){
        case 1 : Insert(first);
        break;
        case 2 : Delete(first);
        break;
        case 3 : RDisplay(first);
        break;
    }
    printf("\nRepeat?(1/0) : ");
    scanf("%d", &a);
    }

    return 0;
}