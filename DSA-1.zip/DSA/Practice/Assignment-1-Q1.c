#include<stdio.h>
struct add{
    float inch, feet;    
} d1, d2, d3;

int main(){
    int a;
    printf("Enter distances : ");
    scanf("%f", &d1.inch);
    scanf("%f", &d2.feet);
    d3.feet = (d1.feet /12) + d2.feet;
    printf("Total distance is %f feet\n", d3.feet);
    return 0;
}

// 1 foot = 12 inch