#include<stdio.h>
struct complex_num{
    int r,i;
};
struct complex_num add(struct complex_num a, struct complex_num b){
    struct complex_num c;
    c.r = a.r + b.r;
    c.i = a.i + b.i;
    return c;
}
int main(){
    struct complex_num a,b,c;
    printf("Enter 1st complex num : ");
    scanf("%d %d", &a.r, &a.i);
    printf("Enter 2nd complex num : ");
    scanf("%d %d", &b.r, &b.i);
    printf("Complex num after adding is ");
    c = add(a, b);
    printf("%d + %di", c.r, c.i);
    return 0;
}
