#include<stdio.h>
struct database{
    int data;
};
int main(){
    struct database *d1;
    d1 = (struct database *)malloc(1 * sizeof(struct database));
    printf("Enter your age : ");
    scanf("%d", &d1->data);
    printf("Age : %d", d1->data);
    return 0;
}