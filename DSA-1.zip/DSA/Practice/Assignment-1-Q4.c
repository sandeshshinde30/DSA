#include<stdio.h>
#include<string.h>
struct employee{
    char name[100];
    float salary;
};
int main(){
    int n;
    printf("Total Records : ");
    scanf("%d", &n);
    
    struct employee e[100];
    for(int i =0; i<n;i++){
        printf("Enter data %d : ", i+1);
        scanf("%s", &e[i].name);
        printf("Enter your salary : ");
        scanf("%f", &e[i].salary);
    }
    e[n].salary = 0;
    for(int i = 0; i<n;i++){
        e[n].salary += e[n].salary+e[i].salary;
    }
    printf("Total salary of workers : %f", e[n].salary);

    return 0;
}