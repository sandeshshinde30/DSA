#include<stdio.h>

int main(){
    int age = 22;
    int *p1 = &age;
    printf("%d\n", *p1);
    return 0;
}