#include<stdio.h>
#include<stdlib.h>
struct Queue{
    int size;
    int front;
    int rear;
    int *Q;
};
void create(struct Queue *q, int size){
    q->size = size;
    q->front = q->rear = -1;
    q->Q=(int *)malloc(q->size*sizeof(int));
};
void enqueue(struct Queue *q){
    char c;
    int item;
    printf("Enter Item : ");
    scanf(" %d", &item);
    printf("Insert from Front/Back (f/b) : ");
    scanf(" %c", &c);

    if(c == 'f'){
        if(q->front == -1){
            printf("Can't Insert.\n");
        }else{
            q->Q[q->front] = item;
            q->front--;
        }
    }else if(c == 'b'){
        if(q->rear == q->size-1){
        printf("\nQueue is Full.");
        return;
    }else{
        q->rear++;
        q->Q[q->rear] = item;
    }
    }
};
int dequeue(struct Queue *q){
    int x = -1;
    char c;
    printf("Delete from Front/Back (f/b) : ");
    scanf(" %c", &c);

    if(c == 'f'){
        if(q->front == q->rear){
            printf("\nQueue is Empty.");
        }else{
            q->front++;
            x = q->Q[q->front];
        }
    }else if(c == 'b'){
        if(q->rear == q->front){
            printf("\nQueue is Empty.");
        }else{
            x = q->Q[q->rear];
            q->rear--;
        }
    }
    return x;
};
void Display(struct Queue q){
    for(int i = q.front+1;i<=q.rear;i++){
        printf("%d ", q.Q[i]);
    }
    printf("\n");
};
int main(){
    struct Queue p;
    create(&p, 4);
    while(1){
    printf("1: Insert\t2: Delete\t3: Display\t4: Exit");
    int n;
    printf("\nEnter your choice : ");
    scanf(" %d", &n);
    switch(n){
        case 1 : enqueue(&p);
        break;
        case 2 : dequeue(&p);
        break;
        case 3 : Display(p);
        break;
        case 4 : exit(0);
        break;
        default : printf("\nInvalid choie");
    }
    }
    return 0;
}
