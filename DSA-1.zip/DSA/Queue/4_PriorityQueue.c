#include<stdio.h>
#include<stdlib.h>
int isempty();
int isfull();
void insert(int, int);
int ghp();
int dhp();
void display();
int rear = -1;
int front = -1;
struct PQ{
    int item;
    int priority;
}pq[10];

int isempty(){
    if(rear == -1){
        return 1;
    }else{
        return 0;
    }
}
int isfull(){
    if(rear == 9){
        return 1;
    }else{
        return 0;
    }
}
void insert(int ele, int p){
    rear += 1;
    pq[rear].item = ele;
    pq[rear].priority = p;
}
int ghp(){
    int i,q=-1;
    if(!isempty()){
        for(i=0;i<=rear;i++){
            if(pq[i].priority > q){
                q = pq[i].priority;
            }
        }
    }
    return q;
}
int dhp(){
    int i,j,t,ele;
    t = ghp();
    for(i=0;i<rear+1;i++){
        if(pq[i].priority == t){
            ele = pq[i].item;
            break;
        }
    }
    if(i<rear){
        for(j=i;j<rear;j++){
            pq[j].item = pq[j+1].item;
            pq[j].priority = pq[j+1].priority;
        }
    }
    rear = rear-1;
    return ele;
}
void display(){
    int i;
    printf("\nPriority Queue : \n ");
    for(i=0;i<=rear;i++){
        printf("item : %d, (priority %d)\n",pq[i].item, pq[i].priority);
    }
}

int main(){
    int ch,p,ele;
    while(1){
        printf("\n1.Insert\n2.Get Highest Priority\n3.Delete Highest Priority\n4.Display\n5.Exit\n");
        printf("Your Choice : ");
        scanf(" %d", &ch);
        switch(ch){
            case 1 : 
            if(isfull()){
                printf("Queue is full.\n");
            }else{
                printf("Enter item : ");
                scanf(" %d", &ele);
                printf("Enter priority : ");
                scanf(" %d", &p);
                insert(ele,p);
            }
            break;
            case 2 : 
                if(isempty()){
                    printf("Queue is Empty.\n");
                }else{
                    p = ghp();
                    printf("\n Highest Priority = %d", p);
                }
            break;
            case 3 : 
            if(isempty()){
                    printf("Queue is Empty.\n");
                }else{
                    ele = dhp();
                    printf("\n%d is Deleted.", ele);
                }
            break;
            case 4 : 
            if(isempty()){
                    printf("Queue is Empty.\n");
                }else{
                    display();
                }
            break;
            case 5 : exit(0);
            break;
            default : printf("Try again.\n");
        }
    };

    return 0;
}