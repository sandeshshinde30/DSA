#include<stdio.h>
int fibo(int n){
    if(n == 0 || n == 1){
        return n;
    }
    else{
        return (fibo(n-2) + fibo(n-1));
    }
}
int main(){
    int n,i;
    printf("Enter a number : ");
    scanf("%d", &n);
    for(i=0; i<n; i++){
          printf("%d \n", fibo(i));
    }
    return 0;
}