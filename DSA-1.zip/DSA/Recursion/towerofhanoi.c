#include<stdio.h>
int count = 0;
void hanoi(int numDisk,char A,char B,char C);
void hanoi(int numDisk,char A,char B,char C){
 if(numDisk!=0){
 hanoi(numDisk - 1,A,B,C);
 printf("\nMove Disk %d to Tower %c\n",numDisk,C);
 hanoi(numDisk - 1,B,C,A);
 count++;
 }
}
int main(){
 int n;
 printf("\nEnter the number of disks : ");
 scanf("%d",&n);
 hanoi(n,'A','B','C');
 printf("\nTotal steps : %d\n",count);
 return 0;
}