#include<stdio.h>
struct Array
{
 int A[10];
 int size;
 int length;
};

void Display(struct Array *p){
    int i;
    for(i=0;i<p->size;i++){
        printf("%d ", p->A[i]);
    }
    printf("\n");
}
int LinearSearch(struct Array arr, int key){
    int i;
    for(i=0;i<arr.length;i++){
        if(key == arr.A[i]){
            return i;
        }
    }
    return -1;
}
int main(){
    struct Array arr = {{2,3,9,16,18,21,28,32,35},10,9};
    printf("Index : %d\n", LinearSearch(arr, 23));
    return 0;
}