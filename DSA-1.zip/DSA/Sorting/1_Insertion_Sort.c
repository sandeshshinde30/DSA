#include<stdio.h>

void display(int a[], int n){
    int i;
    for(i=0;i<n;i++){
        printf("%d ", a[i]);
    }
    printf("\n");
}
void Insertion(int A[], int n){
    int i,j,x;
    for(i=1;i<n;i++){
        j = i-1;
        x = A[i];
        while(j > -1 && A[j] > x){
            A[j+1] = A[j];
            j--;
        }
        A[j+1] = x;
    }
}


int main(){
    int A[] = {11,13,7,2,6,9,4,5,10,3};
    int n = 10;
    display(A, n);
    Insertion(A, n);
    display(A, n);


    return 0;
}