#include<stdio.h>
#include<limits.h>

void display(int a[], int n){
    int i;
    for(i=0;i<n;i++){
        printf("%d ", a[i]);
    }
    printf("\n");
}
void swap(int *x,int *y){
 int temp=*x;
 *x=*y;
 *y=temp;
}

void QuickSort(int a[], int l, int h){
    int j;
    if(l<h){
    j = partition(a, l, h); // find the correct pivot position
    QuickSort(a, l, j);  //left partition
    QuickSort(a, j+1, h); //right partition
    }
}

int partition(int a[], int l, int h){
    int pivot = a[l];
    int i=l, j=h;
    do{
        do{i++;}while(a[i]<=pivot); //find 1st element greater than the pivot
        do{j--;}while(a[j]>pivot); //find 1st element smaller than the pivot
        if(i<j)swap(&a[i], &a[j]); //swapping these
    }while(i<j);
    swap(&a[l], &a[j]);  //swapping the pivot to last element of left partition.
    return j;
}

int main(){
    int A[] = {11,13,7,2,6,9,4,5,10,3, INT_MAX};
    int n = 10;
    display(A, n);
    QuickSort(A,0,10);
    display(A, n);

    return 0;
}