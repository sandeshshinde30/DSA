#include<stdio.h>

void Display(int a[], int n){
    int i;
    for(i=0;i<n;i++){
        printf("%d ", a[i]);
    }
    printf("\n");
}

void Merge(int a[], int l, int mid, int h){
    int i,j,k;
    i = l, j=mid+1, k=l;
    int b[100];
    while(i<=mid && j<=h){
        if(a[i]<a[j]){
            b[k++] = a[i++];
        }else{
            b[k++] = a[j++];
        }
    }
    for(;i<=mid;i++){
        b[k++] = a[i];
    }
    for(;j<=h;j++){
        b[k++] = a[j];
    }
    for(i=l;i<=h;i++){
        a[i] = b[i];
    }
}

void IMergeSort(int a[], int n){
    int p,l,h,mid,i;
    for(p=2;p<=n;p=p*2){
        for(i=0;i+p-1<n;i+=p){
            l = i;
            h = i+p-1;
            mid = (l+h)/2;
            Merge(a,l,mid,h);
        }
    }
    if(p/2 < n){
        Merge(a,0,p/2-1,n-1);
    }
}

int main(){
    int A[] = {3,5,2,76,12,54,45,33,1,86};
    int n=10;
    Display(A,n);
    IMergeSort(A,n);
    Display(A,n);


    return 0;
}