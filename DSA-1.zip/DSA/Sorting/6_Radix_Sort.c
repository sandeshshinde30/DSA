#include<stdio.h>
#include<limits.h>
void RadixSort(int a[], int n);
void countSort(int a[], int n, int exp);
void display(int a[], int n){
    int i;
    for(i=0;i<n;i++){
        printf("%d ", a[i]);
    }
    printf("\n");
}
void swap(int *x,int *y){
 int temp=*x;
 *x=*y;
 *y=temp;
}
int getMax(int a[], int n){
    int mx = a[0];
    for(int i=1;i<n;i++){
        if(a[i] > mx){
            mx = a[i];
        }
    }
    return mx;
}
void RadixSort(int a[], int n){
    int exp, max;
    max = getMax(a, n);
    for(exp=1; max/exp > 0; exp*=10){
        countSort(a, n, exp);
    }       
    display(a, n);
}
void countSort(int a[], int n, int exp){
    int output[n]; // ok
    int i, count[10] = {0};

    for(i=0;i<n;i++){
        count[(a[i]/exp)%10]++;
    }

    for(i=1;i<10;i++){
        count[i] += count[i-1];
    }

    for(i=n-1;i>=0;i--){
        output[count[(a[i]/exp)%10] - 1] = a[i];
        count[(a[i]/exp)%10]--;
    }

    for(i=0;i<n;i++){
        a[i] = output[i];
    }

}
int main(){
    int A[] = {11,13,7,2,6,9,4,5,10,3, INT_MAX};
    int n = 10;
    display(A, n);
    RadixSort(A,10);
    //display(A, n);

    return 0;
}