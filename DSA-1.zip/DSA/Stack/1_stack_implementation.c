#include<stdio.h>
int n, arr[100];
int top = -1;
int size;
void push(){
    int item;
    scanf(" %d", &item);
    size = sizeof(arr)/sizeof(arr[0]);
    if(top == size - 1){
        printf("Stack Overflow\n");
    }
    else{
        top++;
        arr[top] = item;
    }
}
void pop(){
    if(top == -1){
        printf("Stack Underflow\n");
    }
    else{
        printf("%d is Deleted.\n",arr[top]);
        top--;
    }
}
void Top(){
    if(top == -1){
        printf("Stack is Empty.\n");
    }
    else{
        printf("%d\n", arr[top]);
    }
}
void StackSize(){
    if(top == -1){
        printf("Stack is Empty.\n");
    }
    else{
        printf("Size : %d\n", top+1); 
    }
}


int main(){
    char choice;
    do{
    printf("1 : Push\t2: Pop\t3: Top element\t4: Size\nYour choice : ");
    scanf(" %d", &n);
    switch(n){
        case 1 : printf("Push Operation\n");
                push();
        break;
        case 2 : printf("Pop Operatin\n");
                pop();
        break;
        case 3 : printf("Top element : ");
                Top();
        break;
        case 4 : printf("Size of stack : ");
                StackSize();
        break;
        default : printf("Invalid operation.");
    }
    printf("do you want to operate again? y/n : ");
    scanf(" %c", &choice);
    }while(choice == 'y');
    return 0;
}