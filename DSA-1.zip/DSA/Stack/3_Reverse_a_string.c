#include<stdio.h>
#include<string.h>
#define size 100
int top = -1, count=0;
//char stack[size];
char output[size];
void push(char *stack, char temp){
    if(top == size-1){
        printf("Stack Overflow\n");
    }else{
        top++;
        stack[top] = temp;
    }
}

void pop(char *stack, char item){
    if(top == -1){
        printf("Stack Underflow\n");
    }else{
        output[count++] = stack[top--];
    }
}

int main(){
    printf("Enter a string : ");
    char st[size];
    fgets(st, 100, stdin);
    for(int i=0;i<strlen(st);i++){
        push(st, st[i]);
    }
    for(int i=0;i<strlen(st);i++){
        pop(st, st[i]);
    }
    for(int i=0;i<strlen(st);i++){
        printf("%c", output[i]);
    }
    printf("\n");
    return 0;
}