#include<stdio.h>
#include<math.h>
#include<string.h>
char postfix[100];
int top = -1;
int st[100];
void push(int temp, int max);
void pop();
int Top();
void PostEval(char *exp){
    int max = strlen(exp);
    for(int i=0;i<max;i++){
        if(exp[i] - '0' >= 0 && exp[i] - '0' <=9){
            int temp = exp[i] - '0';
            push(temp, max);
        }
        else if(exp[i] == " "){
            continue;
        }
        else{
            if (top < 1) {
                printf("Result is : %d\n", Top(st));
                return;
            }
            int val2 = Top();
            pop();
            int val1 = Top();
            pop();
            switch (exp[i]) {
            case '+': push(val1 + val2, max);
                break;
            case '-': push(val1 - val2, max);
                break;
            case '*': push(val1 * val2, max);
                break;
            case '/': push(val1 / val2, max);
                break;
            case '^' : push(pow(val1, val2), max);
            break;
            }
        }
    }

    printf("Result is : %d\n", Top(st));
}

void push(int temp, int max){
    if(top == max - 1){
        printf("Stack Overflow\n");
    }else{
        top++;
        st[top] = temp;
    }
}

void pop(){
    if(top == -1){
        printf("Stack Underflow\n");
        return;
    }else{
    top--;
    }
}
int Top(){
    if(top != -1){
    return st[top];
    }
    return 0;
}

int main(){
    printf("Enter a valid postfix expression : ");
    fgets(postfix, 100, stdin);
    PostEval(postfix);
    return 0;
}